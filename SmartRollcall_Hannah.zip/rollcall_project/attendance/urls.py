from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('accounts/login/', views.user_login, name='login'),
    path('accounts/logout/', views.user_logout, name='logout'),
    path('accounts/register/', views.register, name='register'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('sign/<int:session_id>/', views.sign_attendance, name='sign_attendance'),
    path('my-attendance/', views.my_attendance, name='my_attendance'),
    path('session/<int:session_id>/', views.session_detail, name='session_detail'),
    path('session/create/', views.create_session, name='create_session'),
    path('session/toggle/<int:session_id>/', views.toggle_session, name='toggle_session'),
    path('admin-panel/', views.admin_panel, name='admin_panel'),
    path('feedback/', views.feedback, name='feedback'),
]
