from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.models import User
from django.contrib import messages
from django.db.models import Count
from .models import Profile, AcademicSession, AttendanceLog, SiteFeedback
from .forms import RegisterForm, FeedbackForm, SessionForm

def home(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    return render(request, 'attendance/home.html')

def user_login(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            messages.success(request, f'Welcome back, {user.first_name}!')
            return redirect('dashboard')
        else:
            messages.error(request, 'Invalid username or password.')
    else:
        form = AuthenticationForm()
    return render(request, 'attendance/login.html', {'form': form})

def user_logout(request):
    logout(request)
    messages.info(request, 'You have been logged out.')
    return redirect('home')

def register(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.first_name = form.cleaned_data['first_name']
            user.last_name = form.cleaned_data['last_name']
            user.email = form.cleaned_data['email']
            user.save()
            Profile.objects.create(
                user=user,
                role=form.cleaned_data['role'],
                registration_id=form.cleaned_data['registration_id'],
                phone=form.cleaned_data.get('phone',''),
                course_program=form.cleaned_data.get('course_program',''),
            )
            login(request, user)
            messages.success(request, f'Welcome, {user.first_name}! Account created.')
            return redirect('dashboard')
    else:
        form = RegisterForm()
    return render(request, 'attendance/register.html', {'form': form})

@login_required
def dashboard(request):
    user = request.user
    is_staff = user.is_staff
    role = getattr(getattr(user, 'profile', None), 'role', None)

    if is_staff or role == 'Lecturer':
        sessions = AcademicSession.objects.filter(lecturer=user)
        total_students = User.objects.filter(profile__role='Student').count()
        active_sessions = sessions.filter(is_active=True).count()
        total_logs = AttendanceLog.objects.filter(session__lecturer=user).count()
        context = {
            'sessions': sessions[:10], 'total_students': total_students,
            'active_sessions': active_sessions, 'total_logs': total_logs,
            'is_lecturer': True,
        }
    else:
        logs = AttendanceLog.objects.filter(student=user).select_related('session')
        active_sessions = AcademicSession.objects.filter(is_active=True)
        signed_ids = logs.values_list('session_id', flat=True)
        context = {
            'logs': logs[:10], 'active_sessions': active_sessions,
            'signed_ids': list(signed_ids), 'total_signed': logs.count(),
            'is_lecturer': False,
        }
    return render(request, 'attendance/dashboard.html', context)

@login_required
def sign_attendance(request, session_id):
    session = get_object_or_404(AcademicSession, id=session_id, is_active=True)
    already = AttendanceLog.objects.filter(student=request.user, session=session).exists()
    if not already:
        AttendanceLog.objects.create(student=request.user, session=session)
        messages.success(request, f'✅ Rollcall signed for {session.course_code}!')
    else:
        messages.info(request, 'You already signed this session.')
    return redirect('dashboard')

@login_required
def my_attendance(request):
    logs = AttendanceLog.objects.filter(student=request.user).select_related('session')
    return render(request, 'attendance/my_attendance.html', {'logs': logs})

@login_required
def session_detail(request, session_id):
    session = get_object_or_404(AcademicSession, id=session_id)
    logs = AttendanceLog.objects.filter(session=session).select_related('student')
    return render(request, 'attendance/session_detail.html', {'session': session, 'logs': logs})

@login_required
def create_session(request):
    if not (request.user.is_staff or getattr(getattr(request.user,'profile',None),'role',None) == 'Lecturer'):
        messages.error(request, 'Only lecturers can create sessions.')
        return redirect('dashboard')
    if request.method == 'POST':
        form = SessionForm(request.POST)
        if form.is_valid():
            s = form.save(commit=False)
            s.lecturer = request.user
            s.save()
            messages.success(request, f'Session {s.course_code} created!')
            return redirect('dashboard')
    else:
        form = SessionForm()
    return render(request, 'attendance/create_session.html', {'form': form})

@login_required
def toggle_session(request, session_id):
    session = get_object_or_404(AcademicSession, id=session_id, lecturer=request.user)
    session.is_active = not session.is_active
    session.save()
    status = 'activated' if session.is_active else 'closed'
    messages.success(request, f'Session {status}.')
    return redirect('dashboard')

@login_required
def admin_panel(request):
    if not request.user.is_staff:
        return redirect('dashboard')
    all_sessions = AcademicSession.objects.all()
    all_users = User.objects.filter(is_staff=False).select_related('profile')
    feedbacks = SiteFeedback.objects.all()
    total_logs = AttendanceLog.objects.count()
    return render(request, 'attendance/admin_panel.html', {
        'all_sessions': all_sessions, 'all_users': all_users,
        'feedbacks': feedbacks, 'total_logs': total_logs,
    })

def feedback(request):
    if request.method == 'POST':
        form = FeedbackForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Thank you! Your feedback has been received.')
            return redirect('feedback')
    else:
        form = FeedbackForm()
    return render(request, 'attendance/feedback.html', {'form': form})
