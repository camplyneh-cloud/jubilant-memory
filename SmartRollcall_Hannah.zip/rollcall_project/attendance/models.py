from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone

class Profile(models.Model):
    USER_TYPES = (('Lecturer', 'Lecturer'), ('Student', 'Student'))
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    role = models.CharField(max_length=20, choices=USER_TYPES)
    registration_id = models.CharField(max_length=50, unique=True)
    phone = models.CharField(max_length=20, blank=True)
    course_program = models.CharField(max_length=100, blank=True)

    def __str__(self):
        return f"{self.user.get_full_name()} ({self.role})"

class AcademicSession(models.Model):
    course_title = models.CharField(max_length=200)
    course_code = models.CharField(max_length=20)
    lecturer = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='sessions')
    venue = models.CharField(max_length=100, blank=True)
    date = models.DateField(default=timezone.now)
    start_time = models.TimeField()
    end_time = models.TimeField()
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.course_code} – {self.course_title} ({self.date})"

    class Meta:
        ordering = ['-date', '-start_time']

class AttendanceLog(models.Model):
    student = models.ForeignKey(User, on_delete=models.CASCADE, related_name='attendance_logs')
    session = models.ForeignKey(AcademicSession, on_delete=models.CASCADE, related_name='logs')
    time_signed = models.DateTimeField(default=timezone.now)

    class Meta:
        unique_together = ('student', 'session')
        ordering = ['-time_signed']

    def __str__(self):
        return f"{self.student.get_full_name()} – {self.session.course_code}"

class SiteFeedback(models.Model):
    sender_name = models.CharField(max_length=100)
    email_address = models.EmailField()
    subject = models.CharField(max_length=200, blank=True)
    content = models.TextField()
    date_sent = models.DateTimeField(auto_now_add=True)
    is_read = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.sender_name} – {self.date_sent.strftime('%d %b %Y')}"

    class Meta:
        ordering = ['-date_sent']
