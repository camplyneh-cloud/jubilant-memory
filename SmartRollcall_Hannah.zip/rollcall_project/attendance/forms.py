from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import Profile, SiteFeedback, AcademicSession

class RegisterForm(UserCreationForm):
    first_name = forms.CharField(max_length=100, required=True)
    last_name = forms.CharField(max_length=100, required=True)
    email = forms.EmailField(required=True)
    role = forms.ChoiceField(choices=[('Student','Student'),('Lecturer','Lecturer')])
    registration_id = forms.CharField(max_length=50)
    phone = forms.CharField(max_length=20, required=False)
    course_program = forms.CharField(max_length=100, required=False)

    class Meta:
        model = User
        fields = ['username','first_name','last_name','email','password1','password2']

class FeedbackForm(forms.ModelForm):
    class Meta:
        model = SiteFeedback
        fields = ['sender_name','email_address','subject','content']
        widgets = {'content': forms.Textarea(attrs={'rows':5})}

class SessionForm(forms.ModelForm):
    class Meta:
        model = AcademicSession
        fields = ['course_title','course_code','venue','date','start_time','end_time','is_active']
        widgets = {
            'date': forms.DateInput(attrs={'type':'date'}),
            'start_time': forms.TimeInput(attrs={'type':'time'}),
            'end_time': forms.TimeInput(attrs={'type':'time'}),
        }
