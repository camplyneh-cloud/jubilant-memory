from django.contrib import admin
from .models import Profile, AcademicSession, AttendanceLog, SiteFeedback

@admin.register(Profile)
class ProfileAdmin(admin.ModelAdmin):
    list_display = ['user', 'role', 'registration_id', 'course_program']
    list_filter = ['role']

@admin.register(AcademicSession)
class SessionAdmin(admin.ModelAdmin):
    list_display = ['course_code', 'course_title', 'lecturer', 'date', 'is_active']
    list_filter = ['is_active', 'date']

@admin.register(AttendanceLog)
class AttendanceLogAdmin(admin.ModelAdmin):
    list_display = ['student', 'session', 'time_signed']

@admin.register(SiteFeedback)
class FeedbackAdmin(admin.ModelAdmin):
    list_display = ['sender_name', 'email_address', 'subject', 'date_sent', 'is_read']
    list_filter = ['is_read']
