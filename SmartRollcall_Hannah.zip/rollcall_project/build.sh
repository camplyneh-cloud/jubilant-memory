#!/usr/bin/env bash
set -o errexit
pip install -r requirements.txt
python manage.py collectstatic --no-input
python manage.py migrate
python manage.py shell -c "
from django.contrib.auth.models import User
from attendance.models import Profile, AcademicSession, SiteFeedback
import datetime

if not User.objects.filter(username='admin').exists():
    admin = User.objects.create_superuser('admin', 'admin@mak.ac.ug', 'admin1234')
    admin.first_name = 'System'; admin.last_name = 'Admin'; admin.save()

    lec = User.objects.create_user('dr.okello', 'okello@mak.ac.ug', 'pass1234')
    lec.first_name = 'Dr. James'; lec.last_name = 'Okello'; lec.save()
    Profile.objects.create(user=lec, role='Lecturer', registration_id='STAFF001')

    stu = User.objects.create_user('hannah.nalugo', 'hannah@students.mak.ac.ug', 'pass1234')
    stu.first_name = 'Hannah'; stu.last_name = 'Nalugo'; stu.save()
    Profile.objects.create(user=stu, role='Student', registration_id='25/U/03509/PSA', course_program='Bachelor of Computer Science')

    AcademicSession.objects.create(
        course_title='Software Development Project', course_code='CSC 1202',
        lecturer=lec, venue='Block A, Room 101', date=datetime.date.today(),
        start_time='08:00', end_time='10:00', is_active=True
    )
"
